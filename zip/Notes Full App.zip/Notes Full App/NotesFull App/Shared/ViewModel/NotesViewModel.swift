//
//  NotesViewModel.swift
//  NotesMacOS
//
//  Created by Balaji on 09/02/22.
//

import SwiftUI
import Firebase
import Combine

class NotesViewModel: ObservableObject {
    
    // MARK: Filtered Array
    @Published var myNotes: [Note]?
    // MARK: Raw All Notes
    @Published var allNotes: [Note]?
    
    // MARK: Search Text
    @Published var searchText: String = ""
    // Combine Search
    var cancellable: AnyCancellable? = nil
    
    // MARK: New Note
    @Published var showAddNotePopup: Bool = false
    @Published var currentCardColor: String = "Blue"
    @Published var noteText: String = ""
    
    // MARK: Alert
    @Published var showAlert: Bool = false
    @Published var alertMsg: String = ""
    
    // MARK: Edit Note
    @Published var editNote: Note?
    
    // MARK: Log Status
    @AppStorage("log_status") var log_status: Bool = false
    // MARK: Logout Alert
    @Published var showLogoutPopup: Bool = false
    
    init(){
        fetchNotes()
        
        // Combine Search
        cancellable = $searchText.removeDuplicates()
            .debounce(for: 0.5, scheduler: RunLoop.main)
            .sink(receiveValue: { string in
                if string != ""{
                    self.filterNotes(searchText: string)
                }
                else{
                    withAnimation{
                        self.myNotes = self.allNotes
                    }
                }
            })
    }
    
    // MARK: Fetching Notes
    func fetchNotes(){
        
        guard let uid = Auth.auth().currentUser?.uid else{
            log_status = false
            return
        }
        
        let notesRef = Firestore.firestore().collection("Users").document(uid).collection("My Notes")
        
        notesRef.order(by: "lastModified", descending: true).addSnapshotListener { snapshot, err in
            guard let docs = snapshot?.documentChanges else{
                return
            }
            
            DispatchQueue.main.async {[self] in
                
                if allNotes == nil{allNotes = []}
                docs.forEach { doc in
                    if let note = try? doc.document.data(as: Note.self){
                     
                        switch doc.type{
                        case .added: allNotes?.append(note)
                        case .modified: updateNote(note: note)
                        case .removed: removeNote(note: note)
                        }
                    }
                }
                sortNotes()
            }
        }
    }
    
    func sortNotes(){
        
        DispatchQueue.global(qos: .userInteractive).async {
            let sorted = self.allNotes?.sorted(by: { first, second in
                return second.date < first.date
            })
            
            DispatchQueue.main.async {[self] in
                allNotes = sorted
                withAnimation(myNotes == nil ? .none : .default){
                    myNotes = allNotes
                }
            }
        }
    }
    
    func filterNotes(searchText: String){
        DispatchQueue.global(qos: .userInteractive).async {
            let filtered = self.allNotes?.filter({ note in
                return note.note.lowercased().contains(searchText.lowercased())
            })
            
            DispatchQueue.main.async {
                withAnimation{
                    self.myNotes = filtered
                }
            }
        }
    }
    
    func addNote(){
        
        guard let uid = Auth.auth().currentUser?.uid else{
            log_status = false
            return
        }
        
        withAnimation{
            showAddNotePopup = false
        }
        if noteText == ""{return}
        
        let notesRef = Firestore.firestore().collection("Users").document(uid).collection("My Notes")
        
        if let editNote = editNote {
            
            notesRef.document(editNote.id ?? "").updateData([
                "note": noteText,
                "lastModified": Date()
            ])
            clearData()
            return
        }
        
        let note = Note(note: noteText, date: Date(), cardColor: currentCardColor)
        
        do{
            let _ = try notesRef.addDocument(from: note)
            clearData()
        }
        catch{
            clearData()
            alertMsg = error.localizedDescription
            showAlert.toggle()
        }
    }
    
    func updateNote(note: Note){
        if let index = myNotes?.firstIndex(where: { currentNote in
            return currentNote.id == note.id
        }){
            allNotes![index] = note
        }
    }
    
    func removeNote(note: Note){
        if let index = myNotes?.firstIndex(where: { currentNote in
            return currentNote.id == note.id
        }){
            allNotes?.remove(at: index)
        }
    }
    
    func deleteNote(){
        guard let editNote = editNote else {
            return
        }
        
        guard let uid = Auth.auth().currentUser?.uid else{
            log_status = false
            return
        }
        
        let notesRef = Firestore.firestore().collection("Users").document(uid).collection("My Notes")
        
        notesRef.document(editNote.id ?? "").delete()
        withAnimation{
            showAddNotePopup = false
        }
        clearData()
    }
    
    func clearData(){
        noteText = ""
        currentCardColor = "Blue"
        editNote = nil
    }
    
    func logout(){
        do{
            try Auth.auth().signOut()
            log_status = false
        }
        catch{
            alertMsg = error.localizedDescription
            showAlert.toggle()
        }
    }
}
