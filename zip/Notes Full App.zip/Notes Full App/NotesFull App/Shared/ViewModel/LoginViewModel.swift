//
//  LoginViewModel.swift
//  SharedLogin (iOS)
//
//  Created by Balaji on 11/01/21.
//

import SwiftUI
import Firebase

class LoginViewModel: ObservableObject {

    @Published var email = ""
    @Published var password = ""
    // Register Re-Enter Password...
    @Published var reEnterPassword = ""
    
    // MARK: Displaying Password
    @Published var showPassword: Bool = false
    @Published var showReEnterPassword: Bool = false
    
    // For Goto registration Page...
    @Published var gotoRegister = false
    
    // MARK: Alert
    @Published var showAlert: Bool = false
    @Published var alertMsg: String = ""
    
    // MARK: Loading
    @Published var isLoading: Bool = false
    
    // MARK: Log Status
    @AppStorage("log_status") var log_status: Bool = false
    
    // Clearing Data When Going to Login / Register Page...
    func clearData(){
        email = ""
        password = ""
        reEnterPassword = ""
    }
    
    func forgotPassword(){
        if email == ""{
            presentAlert(message: "Please enter email ID to procced with resetting the password")
        }
        else{
            Task{
                do{
                    try await Auth.auth().sendPasswordReset(withEmail: email)
                    presentAlert(message: "Reset link sent successfully!")
                }
                catch{
                    presentAlert(message: error.localizedDescription)
                }
            }
        }
    }
    
    func login(){
        if gotoRegister{
            // MARK: Register
            Task{
                await createUser()
            }
        }
        else{
            // MARK: Login
            Task{
                await loginUser()
            }
        }
    }
    
    func loginUser()async{
        if email == "" || password == ""{
            presentAlert(message: "Please fill email/password")
        }
        else{
            do{
                updateLoadadingStatus(status: true)
                
                try await Auth.auth().signIn(withEmail: email, password: password)
                DispatchQueue.main.async {
                    self.log_status = true
                }
                
                updateLoadadingStatus(status: false)
            }
            catch{
                presentAlert(message: error.localizedDescription)
            }
        }
    }
    
    func createUser()async{
        if email == "" || password == "" || reEnterPassword == ""{
            presentAlert(message: "Please fill email/password")
        }
        else if password != reEnterPassword{
            presentAlert(message: "Password mismatch")
        }
        else{
            do{
                updateLoadadingStatus(status: true)
                
                try await Auth.auth().createUser(withEmail: email, password: password)
                DispatchQueue.main.async {
                    self.log_status = true
                }
                
                updateLoadadingStatus(status: false)
            }
            catch{
                presentAlert(message: error.localizedDescription)
            }
        }
    }
    
    func presentAlert(message: String){
        DispatchQueue.main.async {[self] in
            isLoading = false
            alertMsg = message
            showAlert.toggle()
        }
    }
    
    func updateLoadadingStatus(status: Bool){
        DispatchQueue.main.async {
            self.isLoading = status
        }
    }
}
