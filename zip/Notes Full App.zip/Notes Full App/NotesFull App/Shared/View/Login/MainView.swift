//
//  MainView.swift
//  NotesMacOS
//
//  Created by Balaji on 09/02/22.
//

import SwiftUI

struct MainView: View {
    @StateObject var loginData = LoginViewModel()
    var body: some View {
        
        HStack(alignment: .bottom, spacing: 0){
            
            ScrollView(isMacOS() ? .init() : .vertical, showsIndicators: false) {
                
                VStack{
                    
                    HStack{
                        
                        Text("Make Your\nNotes Easier")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.black)
                            .padding(.leading,25)
                        
                        Spacer()
                    }
                    .padding()
                    
                    Image("Logo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding()
                        .padding(.horizontal)
                    
                    // Login / Register Page....
                    
                    // Only For iOS...
                    if !isMacOS(){
                        
                        SideLoginView()
                    }
                }
            }
            
            // For macOS...
            if isMacOS(){
                
                SideLoginView()
            }
        }
        .modifier(AlertModifier(showAlert: $loginData.showAlert, alertMsg: $loginData.alertMsg))
        .frame(maxHeight: .infinity)
        .background((isMacOS() ? nil : Color("LoginBG")).ignoresSafeArea(.all, edges: .all))
        // Setting Frame Only For macOS....
        .frame(width: isMacOS() ? getRect().width / 2 : nil, height: isMacOS() ? getRect().height / 1.8 : nil)
        .environmentObject(loginData)
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}

struct SideLoginView: View {
    
    @EnvironmentObject var loginData: LoginViewModel
    
    var body: some View{
        
        ZStack{
            
            if loginData.gotoRegister{
                Register()
                    // Smooth MacOS Animation...
                    .transition(isMacOS() ? .move(edge: .trailing) : .scale)
            }
            else{
                Login()
                    // Scaling Effect Having Problem In macOS....
                    .transition(isMacOS() ? .move(edge: .trailing) : .scale)
            }
        }
        .disabled(loginData.isLoading)
        .overlay(
        
            ZStack{
                
                if !loginData.isLoading{
                    
                    Button(action: loginData.login, label: {
                        
                        Image(systemName: "arrow.right")
                            .font(.title2)
                            .modifier(LoginButtonModifier())
                    })
                }
                else{
                    ProgressView()
                        .scaleEffect(isMacOS() ? 0.7 : 1)
                        .padding(10)
                        .background(Color.white)
                        .clipShape(Circle())
                }
            }
            .buttonStyle(PlainButtonStyle())
            .offset(x: -65,y: -10)
            
            ,alignment: .bottomTrailing
        )
    }
}
