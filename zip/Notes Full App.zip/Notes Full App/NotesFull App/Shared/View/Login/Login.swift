//
//  Login.swift
//  SharedLogin (iOS)
//
//  Created by Balaji on 11/01/21.
//

import SwiftUI

struct Login: View {
    @EnvironmentObject var loginData : LoginViewModel
    var body: some View {
        
        VStack(alignment: .leading, spacing: 18, content: {
            
            Text("Please Login")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.black)
                .padding(.bottom,isMacOS() ? 0 : 10)
            
            Label(
                title: { TextField("Enter Email", text: $loginData.email)
                    .textFieldStyle(PlainTextFieldStyle())
                },
                icon: { Image(systemName: "envelope")
                    .frame(width: 30)
                    .foregroundColor(.gray)
                })
                
            
            Divider()
            
            Label(
                title: {
                    Group{
                        if loginData.showPassword{
                            TextField("Password", text: $loginData.password)
                        }
                        else{
                            SecureField("Password", text: $loginData.password)
                        }
                    }
                    .textFieldStyle(PlainTextFieldStyle())
                },
                icon: { Image(systemName: "lock")
                    .frame(width: 30)
                    .foregroundColor(.gray)
                })
                .padding(.trailing,30)
                .overlay(
                
                    Button(action: {loginData.showPassword.toggle()}, label: {
                        Image(systemName: loginData.showPassword ? "eye.slash" : "eye")
                            .foregroundColor(.gray)
                    })
                    .buttonStyle(PlainButtonStyle())
                    ,alignment: .trailing
                )
                
            
            Divider()
            
            HStack{
                
                Button(action: loginData.forgotPassword, label: {
                    Text("Forgot details?")
                        .font(.caption)
                        .fontWeight(.bold)
                })
                .buttonStyle(PlainButtonStyle())
                
                Spacer()
                
                Button(action: {
                    // Going to register Page...
                    withAnimation{
                        loginData.clearData()
                        loginData.gotoRegister.toggle()
                    }
                }, label: {
                    Text("Create account")
                        .font(.caption)
                        .fontWeight(.bold)
                })
                .buttonStyle(PlainButtonStyle())
            }
            .foregroundColor(.gray)
        })
        .modifier(LoginViewModifier())
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
