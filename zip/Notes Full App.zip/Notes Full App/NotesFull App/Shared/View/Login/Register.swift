//
//  Register.swift
//  SharedLogin (iOS)
//
//  Created by Balaji on 11/01/21.
//

import SwiftUI

struct Register: View {
    @EnvironmentObject var loginData : LoginViewModel
    var body: some View {
        
        VStack(alignment: .leading, spacing: 18, content: {
            
            Label(
                title: {
                    Text("Please Register")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.black) },
                
                icon: {
                    // Back Button...
                    Button(action: {
                        loginData.clearData()
                        // Moving View Back To Login...
                        withAnimation{
                            loginData.gotoRegister.toggle()
                        }
                    }, label: {
                        
                        Image(systemName: "arrow.left")
                            .font(isMacOS() ? .title2 : .title3)
                            .foregroundColor(.black)
                    })
                    .buttonStyle(PlainButtonStyle())
                })
                .padding(.bottom,isMacOS() ? 0 : 10)
            
            Label(
                title: { TextField("Enter Email", text: $loginData.email)
                    .textFieldStyle(PlainTextFieldStyle())
                },
                icon: { Image(systemName: "envelope")
                    .frame(width: 30)
                    .foregroundColor(.gray)
                })
                
            
            Divider()
            
            Label(
                title: {
                    Group{
                        if loginData.showPassword{
                            TextField("Password", text: $loginData.password)
                        }
                        else{
                            SecureField("Password", text: $loginData.password)
                        }
                    }
                    .textFieldStyle(PlainTextFieldStyle())
                },
                icon: { Image(systemName: "lock")
                    .frame(width: 30)
                    .foregroundColor(.gray)
                })
                .padding(.trailing,30)
                .overlay(
                
                    Button(action: {loginData.showPassword.toggle()}, label: {
                        Image(systemName: loginData.showPassword ? "eye.slash" : "eye")
                            .foregroundColor(.gray)
                    })
                    .buttonStyle(PlainButtonStyle())
                    ,alignment: .trailing
                )
                
            
            Divider()
            
            Label(
                title: {
                    Group{
                        if loginData.showReEnterPassword{
                            TextField("Re-Enter Password", text: $loginData.reEnterPassword)
                        }
                        else{
                            SecureField("Re-Enter Password", text: $loginData.reEnterPassword)
                        }
                    }
                    .textFieldStyle(PlainTextFieldStyle())
                },
                icon: { Image(systemName: "lock")
                    .frame(width: 30)
                    .foregroundColor(.gray)
                })
                .padding(.trailing,30)
                .overlay(
                
                    Button(action: {loginData.showReEnterPassword.toggle()}, label: {
                        Image(systemName: loginData.showReEnterPassword ? "eye.slash" : "eye")
                            .foregroundColor(.gray)
                    })
                    .buttonStyle(PlainButtonStyle())
                    ,alignment: .trailing
                )
                
            
            Divider()
            
        })
        .modifier(LoginViewModifier())
    }
}

struct Resigter_Previews: PreviewProvider {
    static var previews: some View {
        Register()
    }
}
