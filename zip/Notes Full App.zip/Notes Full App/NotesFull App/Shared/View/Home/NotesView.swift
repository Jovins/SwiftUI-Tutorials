//
//  NotesView.swift
//  NotesMacOS
//
//  Created by Balaji on 10/02/22.
//

import SwiftUI

struct NotesView: View {
    @EnvironmentObject var notesData: NotesViewModel
    var body: some View {
        
        ZStack{
            
            if let notes = notesData.myNotes{
                
                if notes.isEmpty{
                    
                    Image("Logo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: isMacOS() ? (getRect().width / 3.5) : nil)
                        .padding(isMacOS() ? 0 : 50)
                }
                else{
                    
                    VStack(spacing: 15){
                        
                        // Columns...
                        #if os(iOS)
                        let columns = Array(repeating: GridItem(.flexible(), spacing: 15), count: (device() == .pad ? 2 : 1))
                        #else
                        let columns = Array(repeating: GridItem(.flexible(), spacing: 25), count: 3)
                        #endif
                        
                        LazyVGrid(columns: columns,spacing: 25) {
                            
                            ForEach(notes){note in
    
                                // Card View....
                                CardView(note: note)
                                    .environmentObject(notesData)
                            }
                        }
                        .padding(.top,30)
                    }
                    .padding(.top,isMacOS() ? 20 : 0)
                    .padding(.horizontal,isMacOS() ? 25 : 15)
                }
            }
            else{
                
                ProgressView()
            }
        }
        .frame(maxWidth: .infinity,maxHeight: .infinity,alignment: .center)
    }
}

struct NotesView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
