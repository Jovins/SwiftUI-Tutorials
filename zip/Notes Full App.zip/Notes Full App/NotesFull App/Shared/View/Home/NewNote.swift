//
//  NewNote.swift
//  NotesMacOS
//
//  Created by Balaji on 10/02/22.
//

import SwiftUI

struct NewNote: View {
    @EnvironmentObject var notesData: NotesViewModel
    
    init(){
        #if os(iOS)
        UITextView.appearance().backgroundColor = .clear
        #endif        
    }
    
    var body: some View {
        TextEditor(text: $notesData.noteText)
            .font(isMacOS() ? .title3 : .body)
            .background(
            
                Text("New Complete App")
                    .font(isMacOS() ? .title3 : .body)
                    .foregroundColor(Color.black.opacity(0.7))
                    .opacity(notesData.noteText == "" ? 1 : 0)
                    .padding(.leading,isMacOS() ? 6 : 4)
                    .offset(y: isMacOS() ? 1 : 9)
                
                ,alignment: .topLeading
            )
            .padding(.top,45)
            .overlay(
                
                VStack(alignment: .trailing,spacing: 8){
                    
                    HStack(spacing: 12){
                        
                        if notesData.editNote != nil{
                            Button(action: notesData.deleteNote) {
                                Image(systemName: "trash.fill")
                                    .font(isMacOS() ? .title2 : .title3)
                                    .foregroundColor(.black)
                            }
                        }
                        
                        Spacer()

                        Button {
                            withAnimation{
                                notesData.showAddNotePopup = false
                                notesData.clearData()
                            }
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .font(isMacOS() ? .title2 : .title3)
                            #if os(iOS)
                                .foregroundColor(.black)
                            #endif
                        }
                    }
                    .overlay(
                    
                        Text("Note")
                            .font(isMacOS() ? .title3 : .body)
                            .foregroundColor(.black)
                    )
                    
                    Rectangle()
                        .frame(height: 1)
                        .background(Color.black.opacity(0.8))
                        .padding(.horizontal,-15)

                    Spacer()
                    
                    Button(action: notesData.addNote){
                     
                        Text("Save")
                            .foregroundColor(.white)
                            .padding(.vertical,8)
                            .padding(.horizontal)
                            .background(Color.black)
                            .clipShape(Capsule())
                    }
                    .disabled(notesData.noteText == "")
                    .opacity(notesData.noteText == "" ? 0.6 : 1)
                }
                
                ,alignment: .trailing
            )
            .padding(15)
            .onAppear {
                if let editNote = notesData.editNote{
                    notesData.noteText = editNote.note
                    notesData.currentCardColor = editNote.cardColor
                }
            }
    }
}

struct NewNote_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
