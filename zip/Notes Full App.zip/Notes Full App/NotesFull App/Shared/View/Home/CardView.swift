//
//  CardView.swift
//  NotesMacOS
//
//  Created by Balaji on 10/02/22.
//

import SwiftUI

struct CardView: View {
    var note: Note
    @EnvironmentObject var notesData: NotesViewModel
    var body: some View {
        
        VStack(spacing: 12){
            
            Text(note.note)
                .font(isMacOS() ? .title3 : .body)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity,alignment: .leading)
            #if os(iOS)
                .frame(height: device() == .pad ? 180 : 120,alignment: .top)
            #else
                .frame(height: 120,alignment: .top)
            #endif
            
            Text(note.date,style: .date)
                .foregroundColor(.black)
                .opacity(0.8)
                .frame(maxWidth: .infinity,alignment: .leading)
        }
        .padding()
        .background(Color(note.cardColor))
        .cornerRadius(18)
        .contentShape(Rectangle())
        .onTapGesture {
            withAnimation{
                notesData.editNote = note
                notesData.showAddNotePopup = true
            }
        }
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
