//
//  Home.swift
//  NotesMacOS (iOS)
//
//  Created by Balaji on 05/10/21.
//

import SwiftUI

struct Home: View {
    
    // Showing Card Colors on Button Click....
    @State var showColors: Bool = false
    
    // Button Animation...
    @State var animateButton: Bool = false
    
    // MARK: Hover Effect MacOS
    @State var hoverColor: Color = .clear
    
    // MARK: Notes Data
    @StateObject var notesData: NotesViewModel = NotesViewModel()
    
    var body: some View {
        
        ScrollView((notesData.myNotes?.isEmpty ?? true) ? .init() : .vertical, showsIndicators: false) {
            
            if (notesData.myNotes?.isEmpty ?? true){
             
                HeaderView()
                    .padding(.top,isMacOS() ? 25 : 15)
                
                NotesView()
                    .environmentObject(notesData)
                    .frame(maxWidth: .infinity,maxHeight: .infinity,alignment: .center)
            }
            else{
             
                LazyVStack(spacing: isMacOS() ? 6 : 12, pinnedViews: [.sectionHeaders]) {
                    
                    Section {
                        NotesView()
                            .environmentObject(notesData)
                    } header: {
                        HeaderView()
                            .padding(.top,isMacOS() ? 25 : 15)
                            .background(Color("BG"))
                            .background(Color("BG").frame(height: 100).ignoresSafeArea().offset(y: -80),alignment: .top)
                    }
                }
            }
        }
        .frame(width: isMacOS() ? getRect().width / 1.7 : nil, height: isMacOS() ? getRect().height - 180 : nil,alignment: .leading)
        .background(Color("BG").ignoresSafeArea())
        .overlay(FAB())
        .popupNavigationView(show: $notesData.showAddNotePopup,background: Color(notesData.currentCardColor)) {
            NewNote()
                .environmentObject(notesData)
        }
    }
    
    @ViewBuilder
    func HeaderView()->some View{
        
        VStack(spacing: isMacOS() ? 6 : 12){
            
            HStack(spacing: 15){
                
                Text("My Notes")
                    .font(isMacOS() ? .system(size: 33, weight: .bold) : .largeTitle.bold())
                    .frame(maxWidth: .infinity,alignment: .leading)
                    .modifier(AlertModifier(showAlert: $notesData.showAlert, alertMsg: $notesData.alertMsg))
                
                if isMacOS(){
                    
                    // Search Bar...
                    HStack(alignment: .top,spacing: 8){
                        Image(systemName: "magnifyingglass")
                            .font(.title3)
                            .foregroundColor(.gray)
                        
                        VStack(spacing: 8){
                            
                            TextField("Search", text: $notesData.searchText)
                            
                            Divider()
                        }
                    }
                    .frame(width: 250,alignment: .leading)
                    .padding(.trailing,8)
                }
                
                Button {
                    notesData.showLogoutPopup.toggle()
                } label: {
                    Image(systemName: "rectangle.portrait.and.arrow.right.fill")
                        .font(.title2)
                    #if os(iOS)
                        .foregroundColor(.black)
                    #endif
                }
                .modifier(LogoutModifier(show: $notesData.showLogoutPopup, onClick: {
                    notesData.logout()
                }))
            }
            .padding(.bottom,isMacOS() ? 0 : 10)
            .padding(.leading,isMacOS() ? 25 : 15)
            .padding(.trailing,15)
            
            if !isMacOS(){
                
                // Search Bar...
                HStack(alignment: .top,spacing: 8){
                    Image(systemName: "magnifyingglass")
                        .font(.title3)
                        .foregroundColor(.gray)
                    
                    TextField("Search", text: $notesData.searchText)
                }
                .padding(.horizontal,15)
                .padding(.bottom,10)
            }
        }
    }
    
    @ViewBuilder
    func FAB()->some View{
        
        VStack{
            
            VStack(spacing: 15){
                
                // Colors...
                let colors = ["Skin","Orange","Purple","Blue","Green"]
                
                ForEach(colors,id: \.self){color in
                    
                    Circle()
                        .fill(Color(color))
                        .frame(width: isMacOS() ? 20 : 25, height: isMacOS() ? 20 : 25)
                        .scaleEffect(hoverColor == Color(color) ? 1.4 : 1)
                        .onHover { status in
                            withAnimation{
                                if status{
                                    hoverColor = Color(color)
                                }
                                else{
                                    hoverColor = .clear
                                }
                            }
                        }
                        .onTapGesture {
                            withAnimation{
                                showColors = false
                                notesData.currentCardColor = color
                                notesData.showAddNotePopup = true
                            }
                        }
                }
            }
            .padding(.top,20)
            .frame(height: showColors ? nil : 0)
            .opacity(showColors ? 1 : 0)
            .zIndex(0)
            
            AddButton()
                .zIndex(1)
        }
        .frame(maxWidth: .infinity,maxHeight: .infinity,alignment: .bottomTrailing)
        .padding()
        // Blur View...
        .background(
            Group{
                #if os(iOS)
                BlurView(style: .systemUltraThinMaterialDark)
                #endif
            }
            .opacity(showColors ? 1 : 0)
            .ignoresSafeArea()
        )
    }
    
    @ViewBuilder
    func AddButton()->some View{
        Button {
            
            if animateButton{return}
            
            withAnimation(.interactiveSpring(response: 0.5, dampingFraction: 0.6, blendDuration: 0.6)){
                showColors.toggle()
                animateButton.toggle()
            }
            
            // Resetting the button...
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                
                withAnimation(.spring()){
                    animateButton.toggle()
                }
            }
            
        } label: {
            
            Image(systemName: "plus")
                .font(.title2)
                .foregroundColor(.white)
                .scaleEffect(animateButton ? 1.1 : 1)
                .rotationEffect(.init(degrees: showColors ? 45 : 0))
                .padding(isMacOS() ? 12 : 15)
                .background(Color.black)
                .clipShape(Circle())
        }
        .scaleEffect(animateButton ? 1.1 : 1)
        .padding(.top,30)
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
