//
//  AlertModifier.swift
//  NotesMacOS
//
//  Created by Balaji on 09/02/22.
//

import SwiftUI

struct AlertModifier: ViewModifier {
    @Binding var showAlert: Bool
    @Binding var alertMsg: String
    func body(content: Content) -> some View {
        
        if #available(iOS 15,macOS 12, *){
            content
                .alert(alertMsg, isPresented: $showAlert) {
                    
                }
        }
        else{
            content
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Message"), message: Text(alertMsg), dismissButton: .destructive(Text("Ok")))
                }
        }
    }
}
