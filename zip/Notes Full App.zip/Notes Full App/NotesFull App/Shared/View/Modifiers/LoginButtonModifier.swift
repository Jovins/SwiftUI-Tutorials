//
//  LoginButtonModifier.swift
//  SharedLogin (iOS)
//
//  Created by Balaji on 11/01/21.
//

import SwiftUI

struct LoginButtonModifier: ViewModifier {
    
    func body(content: Content) -> some View {
        return content
            .aspectRatio(contentMode: .fit)
            .frame(width: isMacOS() ? 16 : 20, height: isMacOS() ? 16 : 20)
            .foregroundColor(.white)
            .padding(12)
            .background(
            
                LinearGradient(gradient: .init(colors: [Color("Gradient1"),Color("Gradient2")]), startPoint: .topLeading, endPoint: .bottomTrailing)
            )
            .clipShape(Circle())
    }
}

