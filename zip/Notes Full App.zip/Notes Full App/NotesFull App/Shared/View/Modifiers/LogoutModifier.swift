//
//  LogoutModifier.swift
//  NotesMacOS
//
//  Created by Balaji on 10/02/22.
//

import SwiftUI

struct LogoutModifier: ViewModifier {
    @Binding var show: Bool
    var onClick: ()->()
    func body(content: Content) -> some View {
        
        Group{
            if #available(iOS 15,macOS 12, *){
                content
                    .alert("Do you want to logout?", isPresented: $show) {
                        Button(role: .destructive) {
                            onClick()
                        } label: {
                            Text("Yes")
                        }

                    }
            }
            else{
                content
                    .alert(isPresented: $show) {
                        Alert(title: Text("Message"), message: Text("Do you want to logout?"), primaryButton: .destructive(Text("Yes"), action: {
                            onClick()
                        }),secondaryButton: .default(Text("Cancel")))
                    }
            }
        }
    }
}
