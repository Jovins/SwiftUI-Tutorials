//
//  Note.swift
//  NotesMacOS (iOS)
//
//  Created by Balaji on 05/10/21.
//

import SwiftUI
import FirebaseFirestoreSwift

// MARK: Note Model
struct Note: Identifiable,Codable{
    @DocumentID var id: String?
    var note: String
    var date: Date
    var cardColor: String
    
    enum CodingKeys: String, CodingKey{
        case id
        case note
        case date="lastModified"
        case cardColor
    }
}
