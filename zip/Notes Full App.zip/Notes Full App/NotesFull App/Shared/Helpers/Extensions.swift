//
//  Extensions.swift
//  NotesMacOS (iOS)
//
//  Created by Balaji on 09/02/22.
//

import SwiftUI

// Extending View to get Frame and getting device os Types...
extension View{
    
    func getRect()->CGRect{
        #if os(iOS)
        return UIScreen.main.bounds
        #else
        return NSScreen.main!.visibleFrame
        #endif
    }
    
    func isMacOS()->Bool{
        #if os(iOS)
        return false
        #endif
        return true
    }
    
    #if os(iOS)
    func device()->UIUserInterfaceIdiom{
        let device = UIDevice.current.userInterfaceIdiom
        
        return device
    }
    #endif
    
    // MARK: Building a Custom Modifier for Custom Popup navigation View
    func popupNavigationView<Content: View>(show: Binding<Bool>,background: Color = .white,@ViewBuilder content: @escaping ()->Content)->some View{
        
        return self
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            .overlay(
                // MARK: Geometry Reader for reading Container Frame
                GeometryReader{proxy in
                    
                    Color.primary
                        .opacity(show.wrappedValue ? 0.35 : 0)
                        .ignoresSafeArea()
                    
                    let size = proxy.size
                    #if os(iOS)
                    let horizontalPadding = device() == .phone ? 30 : (size.width / 4)
                    let height = (size.height / 1.5)
                    #else
                    let horizontalPadding = (size.width / 4)
                    let height = (size.height / 1.7)
                    #endif
                    
                    
                    if show.wrappedValue{
                        
                        content()
                        .frame(width: size.width - horizontalPadding, height: height, alignment: .center)
                        .background(background)
                        // Corner Radius
                        .cornerRadius(15)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .transition(.move(edge: .bottom))
                    }
                }
            )
    }
}

extension ViewModifier{
    func isMacOS()->Bool{
        #if os(iOS)
        return false
        #endif
        return true
    }
}

// Hiding Focus Ring...
#if os(macOS)
extension NSTextField{
    open override var focusRingType: NSFocusRingType{
        get{.none}
        set{}
    }
}
extension NSTextView {
  open override var frame: CGRect {
    didSet {
      backgroundColor = .clear
      drawsBackground = true
      enclosingScrollView?.hasVerticalScroller = false
        
    }
  }
}
#endif
