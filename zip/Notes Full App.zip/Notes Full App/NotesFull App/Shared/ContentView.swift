//
//  ContentView.swift
//  Shared
//
//  Created by Balaji on 05/10/21.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("log_status") var log_status: Bool = false
    var body: some View {

        Group{
            if log_status{
         
                Home()
                    .buttonStyle(BorderlessButtonStyle())
                    .textFieldStyle(PlainTextFieldStyle())
            }
            else{
                MainView()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
