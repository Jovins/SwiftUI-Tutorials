//
//  ContentView.swift
//  Flippo Watch App
//
//  Created by Balaji on 18/09/22.
//

import SwiftUI
import SpriteKit

struct ContentView: View {
    // MARK: Game Scene
    @State var gameScene = GameScene()
    var body: some View {
        GeometryReader{proxy in
            let size = proxy.size
            SpriteView(scene: gameScene,transition: .crossFade(withDuration: 0.45))
                .onAppear {
                    gameScene = GameScene(size: size)
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    updateGameScene(size: size)
                }
        }
        .ignoresSafeArea()
    }
    
    // MARK: Updating Game When Ever User Tap's The Screen
    func updateGameScene(size: CGSize){
        switch gameScene.playerState {
        case .ready:
            gameScene.playerState = .playing

            let fadeOutStartScreen = SKAction.fadeOut(withDuration: 0.5)
            let removeStartScreen = SKAction.removeFromParent()
            
            let startGamePlay = SKAction.run { [self] in
                gameScene.playerScoreLabel.alpha = 1
                gameScene.bird.physicsBody?.isDynamic = true
                gameScene.startDisturbance()
            }

            let sequence = SKAction.sequence([fadeOutStartScreen, startGamePlay, removeStartScreen])
            gameScene.start.run(sequence)

        case .playing:
            gameScene.bird.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
            gameScene.bird.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 2))

        case .dead:
            let scene = GameScene(size: size)
            self.gameScene = scene
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
