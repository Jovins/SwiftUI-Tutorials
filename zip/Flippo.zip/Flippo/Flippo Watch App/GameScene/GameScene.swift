//
//  GameScene.swift
//  Flippo Watch App
//
//  Created by Balaji on 20/09/22.
//

import SpriteKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    // MARK: Game Properties
	var bird: SKSpriteNode!
	var bgMusic: SKAudioNode!
	var start: SKSpriteNode!
	var end: SKSpriteNode!
    
	var playerState = PlayState.ready
	var playerScoreLabel: SKLabelNode!
	var playerScore = 0 {
		didSet {
			playerScoreLabel.text = "\(playerScore)"
		}
	}

    override func sceneDidLoad() {
        setUpGame()
    }
    
    // MARK: Setting Up Game Scene
    func setUpGame(){
        // MARK: Setting Intial Gravity
        // If You Wont Tap It Will Go Down Eventually Collide with Bottom Portion
        physicsWorld.gravity = CGVector(dx: 0.0, dy: -4.5)
        physicsWorld.contactDelegate = self
        
        addBGMusic()
        addBird()
        addBackground()
        addGround()
        addScoreLabel()
        addStart_End()
    }
    
    // MARK: Playing Background Game Music
    func addBGMusic(){
        if let musicURL = Bundle.main.url(forResource: "BGMusic", withExtension: "mp3") {
            bgMusic = SKAudioNode(url:  musicURL)
            bgMusic.autoplayLooped = true
            addChild(bgMusic)
        }
    }

    // MARK: Adding Bird to Scene
	func addBird() {
		let birdUpTexture = SKTexture(imageNamed: "Up")
        let birdFrame = CGRect(origin: .zero, size: CGSize(width: 20, height: 20))
        bird = SKSpriteNode(texture: birdUpTexture, size: birdFrame.size)
		bird.zPosition = 5
		bird.position = CGPoint(x: 20, y: frame.height * 0.85)

		addChild(bird)

        bird.physicsBody = SKPhysicsBody(texture: birdUpTexture, size: birdFrame.size)
		bird.physicsBody!.contactTestBitMask = bird.physicsBody!.collisionBitMask
		bird.physicsBody?.isDynamic = false

		bird.physicsBody?.collisionBitMask = 0

        // MARK: Creating Effect Like Bird is Flying
		let birdMidTexture = SKTexture(imageNamed: "Mid")
		let birdDownTexture = SKTexture(imageNamed: "Down")
		let animation = SKAction.animate(with: [birdUpTexture, birdMidTexture, birdDownTexture, birdMidTexture], timePerFrame: 0.08)
		let runForever = SKAction.repeatForever(animation)

		bird.run(runForever)
	}

    // MARK: Adding Continous Looped Background to Scene
	func addBackground() {
		let backgroundTexture = SKTexture(imageNamed: "BG")

		for index in [0,1] {
			let backgroundNode = SKSpriteNode(texture: backgroundTexture)
            backgroundNode.zPosition = -30
            backgroundNode.anchorPoint = CGPoint(x: 0.5, y: 0.3)
            backgroundNode.position = CGPoint(x: (backgroundTexture.size().width - 2) * CGFloat(index), y: 0)
			addChild(backgroundNode)

			let moveLeft = SKAction.moveBy(x: -backgroundTexture.size().width, y: 0, duration: 15)
			let reset = SKAction.moveBy(x: backgroundTexture.size().width, y: 0, duration: 0)
			let loopBG = SKAction.sequence([moveLeft, reset])
			let foreverAction = SKAction.repeatForever(loopBG)

			backgroundNode.run(foreverAction)
		}
	}

    // MARK: Adding Ground to Detect Collision
	func addGround() {
		let groundTexture = SKTexture(imageNamed: "Ground")
        let groundNode = SKSpriteNode(texture: groundTexture)
        groundNode.zPosition = -100
        groundNode.position = CGPoint(x: 0, y: groundTexture.size().height / 2)

        groundNode.physicsBody = SKPhysicsBody(texture: groundNode.texture!, size: groundNode.texture!.size())
        groundNode.physicsBody?.isDynamic = false

        addChild(groundNode)
	}

    // MARK: Adding Score Label to Scene
    func addScoreLabel() {
		playerScoreLabel = SKLabelNode()
		playerScoreLabel.fontSize = 14
        playerScoreLabel.alpha = 0

		playerScoreLabel.position = CGPoint(x: frame.minX + 25, y: frame.maxY - 30)
		playerScoreLabel.text = "0"
		playerScoreLabel.fontColor = UIColor.black

		addChild(playerScoreLabel)
	}

    // MARK: Adding Start And End Screens to Scene
	func addStart_End() {
        // MARK: Start Screen (Get Ready)
		start = SKSpriteNode(imageNamed: "Start")
		start.position = CGPoint(x: frame.midX, y: frame.midY)
        start.setScale(0.9)
		addChild(start)

        // MARK: End Screen (Game Over)
		end = SKSpriteNode(imageNamed: "End")
		end.position = CGPoint(x: frame.midX, y: frame.midY)
        end.setScale(0.85)
		end.alpha = 0
		addChild(end)
	}
    
    // MARK: Resusable Function for Creating Disturbances
    func disturbance(isRotated: Bool = false)->SKSpriteNode{
        let disturbanceTexture = SKTexture(imageNamed: "Block")
        
        let disturbance = SKSpriteNode(texture: disturbanceTexture)
        disturbance.physicsBody = SKPhysicsBody(texture: disturbanceTexture, size: disturbanceTexture.size())
        disturbance.physicsBody?.isDynamic = false
        if isRotated{
            disturbance.zRotation = .pi
            disturbance.xScale = -1.0
        }
        disturbance.zPosition = -20
        return disturbance
    }

    // MARK: Adding Disturbances
	func addDisturbances() {
        let topDisturbance = disturbance(isRotated: true)
        let bottomDisturbance = disturbance(isRotated: false)
        
        let pointCollision = SKSpriteNode(color: UIColor.clear, size: CGSize(width: 10, height: frame.height))
        pointCollision.physicsBody = SKPhysicsBody(rectangleOf: pointCollision.size)
        pointCollision.physicsBody?.isDynamic = false
        pointCollision.name = "addPoint"

		addChild(topDisturbance)
		addChild(bottomDisturbance)
		addChild(pointCollision)

        // MARK: Decrease This If you want to tough the Game
		let gapDistance: CGFloat = 55
        
        let randomY = CGFloat.random(in: 0...gapDistance)
        let xStart = frame.width + topDisturbance.frame.width

        topDisturbance.position = CGPoint(
            x: xStart,
            y: (topDisturbance.texture!.size().height + gapDistance + randomY)
        )
        bottomDisturbance.position = CGPoint(
            x: xStart,
            y: (topDisturbance.texture!.size().height / 2.1) - gapDistance - randomY
        )
        // MARK: Since Point Collison Width is 10
        pointCollision.position = CGPoint(
            x: xStart + 5.0,
            y: frame.midY
        )
        
        // MARK: Moving The Rock Until Behind the Screen
		let endPosition = frame.width + (topDisturbance.frame.width * 2)
		let endAction = SKAction.moveBy(x: -endPosition, y: 0, duration: 6.2)
        // MARK: Then Removing It
		let endSequence = SKAction.sequence([endAction, SKAction.removeFromParent()])
        
		topDisturbance.run(endSequence)
		bottomDisturbance.run(endSequence)
		pointCollision.run(endSequence)
	}

    // MARK: Creating Disturbance for Every 3 Sec's
	func startDisturbance() {
		let createDisturbance = SKAction.run { [unowned self] in
			self.addDisturbances()
		}

        let waitDuration = SKAction.wait(forDuration: 3)
		let sequence = SKAction.sequence([createDisturbance, waitDuration])
		let repeatForever = SKAction.repeatForever(sequence)

		run(repeatForever)
	}

    // MARK: Checking If Bird is Collided With Any Disturbance Or Land
	func didBegin(_ contact: SKPhysicsContact) {
        // MARK: Checking if Contact Node name is addPoint
        if let nodeA = contact.bodyA.node{
            if nodeA.name == "addPoint"{
                addPoint(node: nodeA)
            }
            else{
                if let nodeB = contact.bodyB.node{
                    if nodeB.name == "addPoint"{
                        addPoint(node: nodeB)
                    }
                    else if nodeA == bird || nodeB == bird{
                        resetPlayer()
                    } else{}
                }
            }
        }
	}
    
    // MARK: Adding Point
    func addPoint(node: SKNode){
        node.removeFromParent()
        let sound = SKAction.playSoundFileNamed("Point.wav", waitForCompletion: false)
        run(sound)

        playerScore += 1
    }
    
    // MARK: Resetting Player For Re-Game
    func resetPlayer(){
        // MARK: Displaying Explosive Particle Emission View In the Postion of Bird
        if let explosion = SKEmitterNode(fileNamed: "Explosion") {
            explosion.position = bird.position
            explosion.particleColorBlendFactor = 1.0
            addChild(explosion)
        }

        let sound = SKAction.playSoundFileNamed("Dead.wav", waitForCompletion: false)
        run(sound)
        
        end.alpha = 1
        playerState = .dead
        bgMusic.run(SKAction.stop())
        bird.removeFromParent()
        speed = 0
    }
}
