//
//  FlippoApp.swift
//  Flippo Watch App
//
//  Created by Balaji on 18/09/22.
//

import SwiftUI

@main
struct Flippo_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
