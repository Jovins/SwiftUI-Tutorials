//
//  PlayerState.swift
//  Flippo Watch App
//
//  Created by Balaji on 20/09/22.
//

import SwiftUI

enum PlayState {
    case ready
    case playing
    case dead
}
